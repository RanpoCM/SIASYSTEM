<?php
session_start();
if (!isset($_SESSION['admin_username'])) {
    header("Location: adminlogin.html");
    exit();
}

$conn = new mysqli("localhost", "root", "", "SIADB");


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST['teacher_username']);
    $password = mysqli_real_escape_string($conn, $_POST['teacher_password']);

   
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    
    $sql = "INSERT INTO teachers (username, password)
            VALUES ('$username', '$hashed_password')";

    if ($conn->query($sql) === TRUE) {
        echo "Teacher created successfully!";
        header("Location: admindashboard.php"); 
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
