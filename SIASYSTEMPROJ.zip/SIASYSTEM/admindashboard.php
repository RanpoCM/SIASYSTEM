<?php
session_start();
if (!isset($_SESSION['admin_username'])) {
    header("Location: adminlogin.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Admin Dashboard</title>
  <link rel="stylesheet" href="style.css" />
  <script src="script.js" defer></script>
  <style>
   
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      display: flex;
      background-color: #f4f7f6;
    }


    .sidebar {
      background: #2c3e50;
      color: white;
      width: 250px;
      padding: 20px;
      height: 100vh;
      position: fixed;
      top: 0;
      left: 0;
      box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
    }

    .sidebar h3 {
      font-size: 24px;
      margin-bottom: 20px;
      color: white;
      text-align: center;
    }

    .sidebar small {
      color: #95a5a6;
      display: block;
      text-align: center;
    }

    .logo {
      display: flex;
      justify-content: center;
      margin-bottom: 30px;
    }

    .logo img {
      width: 150px;
      height: auto;
      border-radius: 10px;
    }


    .sidebar nav button {
      display: block;
      width: 100%;
      margin: 10px 0;
      background: #34495e;
      color: white;
      border: none;
      padding: 15px;
      font-size: 18px;
      text-align: left;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s ease, transform 0.3s ease;
    }


    .sidebar nav button:hover {
      background: #1abc9c;
      transform: scale(1.05);
    }

    .sidebar nav button:focus {
      outline: none;
    }

    
    .main-content {
      flex: 1;
      margin-left: 270px; 
      padding: 30px;
    }


    .top-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    }


    .content-section {
      display: none;
    }

    .content-section.active {
      display: block;
    }


    form input {
      display: block;
      margin: 10px 0;
      padding: 10px;
      width: 100%;
      font-size: 16px;
      border: 1px solid #ccc;
      border-radius: 5px;
      background-color: #f4f4f4;
    }

    form button {
      padding: 10px 20px;
      background: #3498db;
      color: white;
      border: none;
      font-size: 16px;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    form button:hover {
      background: #2980b9;
    }

  
    h2 {
      font-size: 24px;
      color: #333;
    }

   
    .top-bar input {
      padding: 10px;
      width: 200px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    .notif {
      font-size: 24px;
    }

  </style>
</head>
<body>

  <div class="allaroundcontainer">
    <aside class="sidebar">
      <h3>Admin Dashboard</h3>
      <small>SMS Account</small>
      <div class="logo">
        <img src="images/bcplogo.png" alt="Logo" />
      </div>
      <nav>
        <button onclick="showSection('dashboard')">Dashboard</button>
        <button onclick="showSection('teacher')">Teachers</button>
        <button onclick="showSection('studentclasses')">Student/Classes</button>
        <button onclick="showSection('settings')">Settings</button>
        <button onclick="showSection('feature')">Features</button>
        <button onclick="window.location.href='logoutadmin.php'">Logout</button>
      </nav>
    </aside>

    <main class="main-content">
      <header class="top-bar">
        <input type="text" placeholder="Search..." />
        <div class="notif">🔔</div>
      </header>

      <section id="dashboard" class="content-section active">
        <h1>Welcome to the Admin Dashboard</h1>
      </section>

      <section id="teacher" class="content-section">
        <h2>Teachers Section</h2>
        <form action="createteacher.php" method="POST">
          <input type="text" name="teacher_username" placeholder="Username" required />
          <input type="password" name="teacher_password" placeholder="Password" required />
          <button type="submit">Create Teacher</button>
        </form>
      </section>

      <section id="studentclasses" class="content-section">
        <h2>Create Student Account</h2>
        <form action="createstudent.php" method="POST">
          <input type="text" name="student_username" placeholder="Username" required />
          <input type="password" name="student_password" placeholder="Password" required />
          <button type="submit">Create Student</button>
        </form>
      </section>

      <section id="settings" class="content-section">
        <h2>Settings and Profile</h2>
      </section>

      <section id="feature" class="content-section">
        <h2>Feature Section</h2>
      </section>

    </main>
  </div>
  
</body>
</html>
