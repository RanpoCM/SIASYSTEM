<?php
$conn = new mysqli("localhost", "root", "", "SIADB");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = mysqli_real_escape_string($conn, $_POST['student_username']);
$password = password_hash($_POST['student_password'], PASSWORD_DEFAULT);

$sql = "INSERT INTO students (username, password) VALUES ('$username', '$password')";
if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Student created successfully'); window.location.href='admindashboard.php';</script>";
} else {
    echo "Error: " . $conn->error;
}
$conn->close();
?>
