<?php
session_start();
$conn = new mysqli("localhost", "root", "", "SIADB");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = mysqli_real_escape_string($conn, $_POST['username']);
$password = $_POST['password'];

$sql = "SELECT * FROM students WHERE username='$username'";
$result = $conn->query($sql);

if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['password'])) {
        $_SESSION['student_username'] = $username;
        header("Location: studentdashboard.html");
        exit();
    }
}
echo "Invalid credentials.";
$conn->close();
?>

